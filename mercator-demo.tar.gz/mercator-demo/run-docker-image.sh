#!/bin/bash

docker run -it -p 7474:7474 -p 7687:7687 -v ~/.aws:/root/.aws mercator-demo


